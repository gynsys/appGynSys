--
-- PostgreSQL database dump
--

\restrict NwizehYeairjyhWg7mvIH9gcLvNhwedECpunq5kF1YbaD17HWDwD1kiw31Nb60y

-- Dumped from database version 15.15
-- Dumped by pg_dump version 15.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: tenantstatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.tenantstatus AS ENUM (
    'ACTIVE',
    'PAUSED',
    'SUSPENDED'
);


ALTER TYPE public.tenantstatus OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO postgres;

--
-- Name: appointments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.appointments (
    id integer NOT NULL,
    doctor_id integer NOT NULL,
    patient_name character varying NOT NULL,
    patient_email character varying,
    patient_phone character varying,
    appointment_date timestamp with time zone NOT NULL,
    appointment_type character varying,
    notes text,
    status character varying,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone,
    reason_for_visit character varying,
    preconsulta_answers text
);


ALTER TABLE public.appointments OWNER TO postgres;

--
-- Name: appointments_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.appointments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.appointments_id_seq OWNER TO postgres;

--
-- Name: appointments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.appointments_id_seq OWNED BY public.appointments.id;


--
-- Name: blog_comments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.blog_comments (
    id integer NOT NULL,
    post_id integer NOT NULL,
    author_name character varying NOT NULL,
    content text NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    ip_address character varying
);


ALTER TABLE public.blog_comments OWNER TO postgres;

--
-- Name: blog_comments_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.blog_comments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.blog_comments_id_seq OWNER TO postgres;

--
-- Name: blog_comments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.blog_comments_id_seq OWNED BY public.blog_comments.id;


--
-- Name: blog_posts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.blog_posts (
    id integer NOT NULL,
    title character varying NOT NULL,
    slug character varying NOT NULL,
    content text NOT NULL,
    summary character varying,
    cover_image character varying,
    is_published boolean,
    published_at timestamp without time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone,
    doctor_id integer NOT NULL,
    is_in_menu boolean,
    menu_weight integer,
    menu_icon character varying
);


ALTER TABLE public.blog_posts OWNER TO postgres;

--
-- Name: blog_posts_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.blog_posts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.blog_posts_id_seq OWNER TO postgres;

--
-- Name: blog_posts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.blog_posts_id_seq OWNED BY public.blog_posts.id;


--
-- Name: consultations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.consultations (
    id integer NOT NULL,
    doctor_id integer NOT NULL,
    patient_id integer,
    patient_name character varying,
    patient_ci character varying,
    patient_age character varying,
    patient_phone character varying,
    reason_for_visit text,
    family_history_mother text,
    family_history_father text,
    personal_history text,
    supplements text,
    surgical_history text,
    obstetric_history_summary text,
    functional_exam_summary text,
    habits_summary text,
    physical_exam text,
    ultrasound text,
    diagnosis text,
    plan text,
    observations text,
    history_number character varying,
    pdf_path character varying,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


ALTER TABLE public.consultations OWNER TO postgres;

--
-- Name: consultations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.consultations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.consultations_id_seq OWNER TO postgres;

--
-- Name: consultations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.consultations_id_seq OWNED BY public.consultations.id;


--
-- Name: doctors; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.doctors (
    id integer NOT NULL,
    email character varying NOT NULL,
    password_hash character varying,
    nombre_completo character varying NOT NULL,
    especialidad character varying,
    biografia character varying,
    slug_url character varying NOT NULL,
    logo_url character varying,
    photo_url character varying,
    theme_primary_color character varying,
    is_active boolean,
    is_verified boolean,
    status character varying NOT NULL,
    plan_id integer,
    payment_reference character varying,
    role character varying NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone,
    social_youtube character varying,
    social_instagram character varying,
    social_tiktok character varying,
    social_x character varying,
    social_facebook character varying,
    schedule json,
    contact_email character varying,
    card_shadow boolean DEFAULT true,
    container_shadow boolean DEFAULT true,
    theme_body_bg_color character varying,
    theme_container_bg_color character varying,
    pdf_config json,
    universidad character varying,
    services_section_title character varying,
    gallery_width character varying DEFAULT '100%'::character varying,
    stripe_customer_id character varying,
    subscription_end_date timestamp with time zone
);


ALTER TABLE public.doctors OWNER TO postgres;

--
-- Name: doctors_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.doctors_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.doctors_id_seq OWNER TO postgres;

--
-- Name: doctors_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.doctors_id_seq OWNED BY public.doctors.id;


--
-- Name: faqs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.faqs (
    id integer NOT NULL,
    doctor_id integer NOT NULL,
    question character varying NOT NULL,
    answer text NOT NULL,
    display_order integer,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone
);


ALTER TABLE public.faqs OWNER TO postgres;

--
-- Name: faqs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.faqs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.faqs_id_seq OWNER TO postgres;

--
-- Name: faqs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.faqs_id_seq OWNED BY public.faqs.id;


--
-- Name: gallery_images; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.gallery_images (
    id integer NOT NULL,
    doctor_id integer NOT NULL,
    image_url character varying NOT NULL,
    title character varying,
    description text,
    display_order integer,
    is_active boolean,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone,
    featured boolean,
    crop json
);


ALTER TABLE public.gallery_images OWNER TO postgres;

--
-- Name: gallery_images_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.gallery_images_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gallery_images_id_seq OWNER TO postgres;

--
-- Name: gallery_images_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.gallery_images_id_seq OWNED BY public.gallery_images.id;


--
-- Name: locations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.locations (
    id integer NOT NULL,
    doctor_id integer NOT NULL,
    name character varying NOT NULL,
    address character varying NOT NULL,
    city character varying,
    google_maps_url character varying,
    phone character varying,
    is_active boolean,
    image_url character varying
);


ALTER TABLE public.locations OWNER TO postgres;

--
-- Name: locations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.locations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.locations_id_seq OWNER TO postgres;

--
-- Name: locations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.locations_id_seq OWNED BY public.locations.id;


--
-- Name: modules; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.modules (
    id integer NOT NULL,
    name character varying NOT NULL,
    description text,
    code character varying NOT NULL,
    is_active boolean,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone
);


ALTER TABLE public.modules OWNER TO postgres;

--
-- Name: modules_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.modules_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.modules_id_seq OWNER TO postgres;

--
-- Name: modules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.modules_id_seq OWNED BY public.modules.id;


--
-- Name: patients; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.patients (
    id integer NOT NULL,
    name character varying NOT NULL,
    email character varying,
    phone character varying,
    date_of_birth timestamp with time zone,
    medical_history text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone,
    tenant_id character varying
);


ALTER TABLE public.patients OWNER TO postgres;

--
-- Name: patients_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.patients_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.patients_id_seq OWNER TO postgres;

--
-- Name: patients_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.patients_id_seq OWNED BY public.patients.id;


--
-- Name: plans; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.plans (
    id integer NOT NULL,
    name character varying NOT NULL,
    description character varying,
    price numeric(10,2),
    features json,
    max_testimonials integer,
    max_gallery_images integer,
    max_faqs integer,
    custom_domain boolean,
    analytics_dashboard boolean,
    priority_support boolean,
    is_active boolean,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone
);


ALTER TABLE public.plans OWNER TO postgres;

--
-- Name: plans_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.plans_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.plans_id_seq OWNER TO postgres;

--
-- Name: plans_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.plans_id_seq OWNED BY public.plans.id;


--
-- Name: preconsultation_questions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.preconsultation_questions (
    id character varying NOT NULL,
    text text NOT NULL,
    type character varying NOT NULL,
    category character varying NOT NULL,
    required boolean,
    options json,
    "order" integer,
    is_active boolean
);


ALTER TABLE public.preconsultation_questions OWNER TO postgres;

--
-- Name: services; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.services (
    id integer NOT NULL,
    doctor_id integer NOT NULL,
    title character varying NOT NULL,
    description text,
    image_url character varying,
    is_active boolean,
    "order" integer,
    blog_slug character varying
);


ALTER TABLE public.services OWNER TO postgres;

--
-- Name: services_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.services_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.services_id_seq OWNER TO postgres;

--
-- Name: services_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.services_id_seq OWNED BY public.services.id;


--
-- Name: tenant_modules; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tenant_modules (
    tenant_id integer NOT NULL,
    module_id integer NOT NULL,
    is_enabled boolean,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone
);


ALTER TABLE public.tenant_modules OWNER TO postgres;

--
-- Name: tenants; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tenants (
    id integer NOT NULL,
    email character varying NOT NULL,
    password_hash character varying,
    nombre_completo character varying NOT NULL,
    telefono character varying,
    especialidad character varying,
    biografia character varying,
    slug character varying NOT NULL,
    logo_url character varying,
    photo_url character varying,
    theme_primary_color character varying,
    plan_id integer,
    status public.tenantstatus,
    is_verified boolean,
    stripe_customer_id character varying,
    subscription_end_date timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone
);


ALTER TABLE public.tenants OWNER TO postgres;

--
-- Name: tenants_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tenants_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tenants_id_seq OWNER TO postgres;

--
-- Name: tenants_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tenants_id_seq OWNED BY public.tenants.id;


--
-- Name: testimonials; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.testimonials (
    id integer NOT NULL,
    doctor_id integer NOT NULL,
    patient_name character varying NOT NULL,
    patient_email character varying,
    photo_url character varying,
    content text NOT NULL,
    rating integer,
    is_approved boolean,
    is_featured boolean,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone
);


ALTER TABLE public.testimonials OWNER TO postgres;

--
-- Name: testimonials_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.testimonials_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.testimonials_id_seq OWNER TO postgres;

--
-- Name: testimonials_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.testimonials_id_seq OWNED BY public.testimonials.id;


--
-- Name: appointments id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.appointments ALTER COLUMN id SET DEFAULT nextval('public.appointments_id_seq'::regclass);


--
-- Name: blog_comments id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blog_comments ALTER COLUMN id SET DEFAULT nextval('public.blog_comments_id_seq'::regclass);


--
-- Name: blog_posts id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blog_posts ALTER COLUMN id SET DEFAULT nextval('public.blog_posts_id_seq'::regclass);


--
-- Name: consultations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.consultations ALTER COLUMN id SET DEFAULT nextval('public.consultations_id_seq'::regclass);


--
-- Name: doctors id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.doctors ALTER COLUMN id SET DEFAULT nextval('public.doctors_id_seq'::regclass);


--
-- Name: faqs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.faqs ALTER COLUMN id SET DEFAULT nextval('public.faqs_id_seq'::regclass);


--
-- Name: gallery_images id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gallery_images ALTER COLUMN id SET DEFAULT nextval('public.gallery_images_id_seq'::regclass);


--
-- Name: locations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.locations ALTER COLUMN id SET DEFAULT nextval('public.locations_id_seq'::regclass);


--
-- Name: modules id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.modules ALTER COLUMN id SET DEFAULT nextval('public.modules_id_seq'::regclass);


--
-- Name: patients id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.patients ALTER COLUMN id SET DEFAULT nextval('public.patients_id_seq'::regclass);


--
-- Name: plans id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plans ALTER COLUMN id SET DEFAULT nextval('public.plans_id_seq'::regclass);


--
-- Name: services id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.services ALTER COLUMN id SET DEFAULT nextval('public.services_id_seq'::regclass);


--
-- Name: tenants id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tenants ALTER COLUMN id SET DEFAULT nextval('public.tenants_id_seq'::regclass);


--
-- Name: testimonials id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.testimonials ALTER COLUMN id SET DEFAULT nextval('public.testimonials_id_seq'::regclass);


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.alembic_version (version_num) FROM stdin;
52a0c5859330
\.


--
-- Data for Name: appointments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.appointments (id, doctor_id, patient_name, patient_email, patient_phone, appointment_date, appointment_type, notes, status, created_at, updated_at, reason_for_visit, preconsulta_answers) FROM stdin;
\.


--
-- Data for Name: blog_comments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.blog_comments (id, post_id, author_name, content, created_at, ip_address) FROM stdin;
\.


--
-- Data for Name: blog_posts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.blog_posts (id, title, slug, content, summary, cover_image, is_published, published_at, created_at, updated_at, doctor_id, is_in_menu, menu_weight, menu_icon) FROM stdin;
1	¿Qué es la Endometriosis?	entendiendo-la-endometriosis	La endometriosis es una condición donde el tejido similar al revestimiento del útero crece fuera de él...	\N	\N	t	\N	2025-12-20 13:39:26.007962+00	\N	4	t	0	\N
2	Importancia del Control Anual	importancia-control-anual	El chequeo ginecológico anual es vital para prevenir...	\N	\N	t	\N	2025-12-20 13:39:26.007962+00	\N	4	t	0	\N
4	Estadísticas Alarmantes del VPH en el Mundo	estadisticas-vph-mundo	\n                <h2>Una Pandemia Silenciosa</h2>\n                <p>El <strong>Virus del Papiloma Humano (VPH)</strong> es la infección de transmisión sexual más común del mundo. Se estima que el 80% de las personas sexualmente activas contraerán al menos un tipo de VPH en algún momento de sus vidas.</p>\n\n                <h3>Cifras que Preocupan</h3>\n                <ul>\n                    <li>Más de 600,000 nuevos casos de cáncer de cuello uterino se diagnostican anualmente, casi todos relacionados con el VPH.</li>\n                    <li>La tasa de mortalidad es significativamente mayor en países en vías de desarrollo debido a la falta de acceso a pruebas de Papanicolau (citología).</li>\n                </ul>\n\n                <h3>La Vacuna: Nuestra Mejor Arma</h3>\n                <p>La vacunación masiva, idealmente antes del inicio de la vida sexual, ha demostrado reducir drásticamente la incidencia de cánceres relacionados con el VPH. No es solo un asunto de mujeres; la vacunación en hombres es crucial para la inmunidad de rebaño.</p>\n                	Un análisis profundo sobre la prevalencia del Virus del Papiloma Humano a nivel global y la importancia crítica de la vacunación.	\N	t	2025-12-20 14:50:15.465399	2025-12-20 14:50:15.438975+00	\N	4	t	0	\N
5	El Desafío del Diagnóstico de la Endometriosis	dificultad-diagnostico-endometriosis	\n                <h2>¿Dolor "Normal"? El Gran Mito</h2>\n                <p>La principal barrera para el diagnóstico de la <strong>endometriosis</strong> es la normalización del dolor menstrual. Muchas mujeres crecen escuchando que sufrir es parte de ser mujer.</p>\n\n                <h3>La Enfermedad Camaleónica</h3>\n                <p>La endometriosis puede presentar síntomas muy variados: desde dolor pélvico crónico e infertilidad, hasta problemas digestivos o urinarios que confunden a los médicos generalistas, llevándolos a diagnósticos erróneos como Síndrome de Intestino Irritable.</p>\n\n                <h3>La Necesidad de Especialistas</h3>\n                <p>El diagnóstico definitivo a menudo requiere cirugía laparoscópica o un mapeo ecográfico realizado por un ojo experto. La falta de especialistas entrenados en <em>mapeo de endometriosis</em> contribuye al retraso diagnóstico.</p>\n                	¿Por qué tardan en promedio 7 años en diagnosticar la endometriosis? Analizamos las barreras médicas y sociales.	\N	t	2025-12-20 14:50:15.468474	2025-12-20 14:50:15.438975+00	\N	4	t	0	\N
6	Casos Raros: Endometriosis Apendicular	casos-raros-endometriosis-apendice	\n                <h2>Más Allá de la Pelvis</h2>\n                <p>Aunque es raro, el tejido endometrial puede migrar a órganos distantes. La <strong>endometriosis apendicular</strong> es una de estas manifestaciones extragenitales poco comunes pero peligrosas.</p>\n\n                <h3>Síntomas Confusos</h3>\n                <p>A menudo se presenta como una apendicitis aguda o dolor crónico en fosa ilíaca derecha que empeora con la menstruación (amenorrea catamenial). Esto hace que el diagnóstico preoperatorio sea extremadamente difícil.</p>\n\n                <h3>Tratamiento Quirúrgico</h3>\n                <p>El abordaje suele requerir una apendicectomía. Es vital que, durante cualquier laparoscopia por dolor pélvico crónico, el cirujano inspeccione sistemáticamente el apéndice, el diafragma y el intestino.</p>\n                	La endometriosis no solo afecta el útero. Reporte sobre casos extragenitales y su complejidad quirúrgica.	\N	t	2025-12-20 14:50:15.474561	2025-12-20 14:50:15.438975+00	\N	4	f	0	\N
7	Mitos y Verdades: Embarazo y Ginecología	mitos-verdades-embarazo	\n                <h2>Mito 1: 'Debes comer por dos'</h2>\n                <p><strong>Falso.</strong> Las necesidades calóricas solo aumentan ligeramente en el segundo y tercer trimestre. El exceso de peso aumenta riesgos de diabetes gestacional y preeclampsia.</p>\n\n                <h2>Mito 2: 'La forma de la barriga predice el sexo'</h2>\n                <p><strong>Falso.</strong> La forma depende del tono muscular abdominal de la madre, la posición del feto y la cantidad de embarazos previos, no del sexo del bebé.</p>\n\n                <h2>Mito 3: 'No puedes teñirte el cabello'</h2>\n                <p><strong>Verdad a medias.</strong> Se recomienda evitar tintes con amoníaco y esperar idealmente hasta pasado el primer trimestre, pero los productos modernos suelen ser seguros.</p>\n                	Desmentimos las creencias populares más arraigadas sobre la gestación y la salud femenina.	\N	t	2025-12-20 14:50:15.484707	2025-12-20 14:50:15.438975+00	\N	4	f	0	\N
8	La Importancia del Control Anual	importancia-control-anual-ginecologico	\n                <h2>Prevenir es Curar</h2>\n                <p>Muchas patologías ginecológicas, desde el cáncer de cuello uterino hasta miomas o quistes, son asintomáticas en sus etapas iniciales.</p>\n\n                <h3>¿Qué incluye un chequeo completo?</h3>\n                <ul>\n                    <li><strong>Citología (Papanicolau):</strong> Para detectar cambios celulares pre-cancerosos.</li>\n                    <li><strong>Ecografía Transvaginal:</strong> Para evaluar útero y ovarios.</li>\n                    <li><strong>Examen Mamario:</strong> Vital para la detección temprana del cáncer de mama.</li>\n                </ul>\n                <p>No esperes a sentir dolor. Agenda tu cita anual hoy mismo.</p>\n                	Tu chequeo anual es más que un simple trámite. Es la piedra angular de la medicina preventiva femenina.	\N	t	2025-12-20 14:50:15.486582	2025-12-20 14:50:15.438975+00	\N	4	t	0	\N
3	La Medicina del Futuro: Visión 2045	medicina-del-futuro-2045	<h2>El Amanecer de una Nueva Era Médica</h2><p>Para el año 2045, la medicina habrá dado un salto cuántico. En el campo de la <strong>ginecología</strong>, esperamos ver avances impensables hoy en día.</p><h3>Úteros Artificiales y Gestación Externa</h3><p>La tecnología de ectogénesis podría permitir el desarrollo fetal completo fuera del cuerpo humano, ofreciendo esperanza a mujeres con infertilidad uterina grave.</p><h3>Diagnóstico con Nanobots</h3><p>Imaginamos nanobots circulando en el torrente sanguíneo, capaces de detectar marcadores de VPH o células endometriósicas antes de que sean visibles en una ecografía tradicional.</p><h3>Medicina Personalizada y Genómica</h3><p>Los tratamientos hormonales ya no serán 'talla única'. Se diseñarán específicamente basados en el perfil genético único de cada paciente, minimizando efectos secundarios.</p>	Exploramos cómo la inteligencia artificial, la nanotecnología y la genómica revolucionarán la ginecología para el año 2045.	/uploads/blog/4_blog_cover_20251220_150220.png	t	2025-12-20 14:50:15.459719	2025-12-20 14:50:15.438975+00	2025-12-20 15:02:22.975581+00	4	f	0	
\.


--
-- Data for Name: consultations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.consultations (id, doctor_id, patient_id, patient_name, patient_ci, patient_age, patient_phone, reason_for_visit, family_history_mother, family_history_father, personal_history, supplements, surgical_history, obstetric_history_summary, functional_exam_summary, habits_summary, physical_exam, ultrasound, diagnosis, plan, observations, history_number, pdf_path, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: doctors; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.doctors (id, email, password_hash, nombre_completo, especialidad, biografia, slug_url, logo_url, photo_url, theme_primary_color, is_active, is_verified, status, plan_id, payment_reference, role, created_at, updated_at, social_youtube, social_instagram, social_tiktok, social_x, social_facebook, schedule, contact_email, card_shadow, container_shadow, theme_body_bg_color, theme_container_bg_color, pdf_config, universidad, services_section_title, gallery_width, stripe_customer_id, subscription_end_date) FROM stdin;
4	milanopabloe@gmail.com	$2b$12$hNP854WKFl7GEHFbyFp.b.je/vbcq3ya0o2nx.iV5EXC1nCv6f.am	Dra. Mariel Herrera	Ginecología y Obstetricia	<h3 class="ql-align-justify"><span style="color: rgb(68, 68, 68);">"Soy la </span><strong style="color: rgb(68, 68, 68);">Dra. Mariel Herrera</strong><span style="color: rgb(68, 68, 68);">, Ginecóloga-Obstetra especializada en </span><strong style="color: rgb(68, 68, 68);">endometriosis </strong><span style="color: rgb(68, 68, 68);">y salud femenina integral. Egresada de la </span><strong style="color: rgb(68, 68, 68);">Universidad Central de Venezuela</strong><span style="color: rgb(68, 68, 68);">, mi formación avanzada se centra en el</span><strong style="color: rgb(68, 68, 68);"> diagnóstico y tratamiento</strong><span style="color: rgb(68, 68, 68);"> de esta condición que afecta a tantas mujeres. Ofrezco una atención personalizada y actualizada, combinando los últimos avances médicos con un enfoque humano y empático. Mi compromiso es acompañarte en todas las etapas: adolescencia, fertilidad, embarazo y menopausia. En mi consulta encontrarás un espacio de </span><strong style="color: rgb(68, 68, 68);">confianza y profesionalismo</strong><span style="color: rgb(68, 68, 68);"> dedicado a tu bienestar. Sígueme en Instagram </span><a href="https://www.instagram.com/draendog?igsh=cG1pZjZhYWxldmVv" rel="noopener noreferrer" target="_blank" style="color: rgb(68, 68, 68);">@draendog</a><span style="color: rgb(68, 68, 68);"> donde comparto </span><strong style="color: rgb(68, 68, 68);"><em>consejos sobre salud ginecológica y endometriosis</em></strong><span style="color: rgb(68, 68, 68);">."</span></h3>	mariel-herrera	/uploads/logos/4_logo_20251220_145425.png	/uploads/photos/4_photo_20251220_143449.png	#820845	t	f	active	1	SEED_DATA	user	2025-12-20 13:22:05.021024+00	2025-12-20 14:54:25.186836+00						\N	milanopabloe@gmail.com	f	f	#f3f1f1	#ffffff	\N	Universidad Central de Venezuela	Mi Servicios	100%	\N	\N
\.


--
-- Data for Name: faqs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.faqs (id, doctor_id, question, answer, display_order, created_at, updated_at) FROM stdin;
1	4	¿Dónde es la consulta?	Atiendo en Caracas y Guarenas.	0	2025-12-20 13:32:09.517681+00	\N
2	4	¿Trabaja con seguros?	Sí, trabajo con los principales seguros nacionales e internacionales.	0	2025-12-20 13:32:09.517681+00	\N
3	4	¿Realiza ecosonogramas?	Sí, realizo ecosonogramas pélvicos y obstétricos en el consultorio.	0	2025-12-20 13:32:09.517681+00	\N
\.


--
-- Data for Name: gallery_images; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.gallery_images (id, doctor_id, image_url, title, description, display_order, is_active, created_at, updated_at, featured, crop) FROM stdin;
1	4	/sample-gallery/img1.svg	Imagen 1	\N	1	t	2025-12-20 13:32:09.517681+00	\N	f	\N
2	4	/sample-gallery/img2.svg	Imagen 2	\N	2	t	2025-12-20 13:32:09.517681+00	\N	f	\N
3	4	/sample-gallery/img3.svg	Imagen 3	\N	3	t	2025-12-20 13:32:09.517681+00	\N	f	\N
4	4	/sample-gallery/img4.svg	Imagen 4	\N	4	t	2025-12-20 13:32:09.517681+00	\N	f	\N
5	4	/sample-gallery/img5.svg	Imagen 5	\N	5	t	2025-12-20 13:32:09.517681+00	\N	f	\N
\.


--
-- Data for Name: locations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.locations (id, doctor_id, name, address, city, google_maps_url, phone, is_active, image_url) FROM stdin;
1	4	Consultorio Caracas	Av. Principal de Las Mercedes, Centro Profesional, Piso 5	Caracas	\N	0424-4281876	t	\N
2	4	Consultorio Guarenas	CC Buenaventura, Vista Place, Nivel Salud	Guarenas	\N	0412-7738918	t	\N
\.


--
-- Data for Name: modules; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.modules (id, name, description, code, is_active, created_at, updated_at) FROM stdin;
1	Blog	Blog functionality	blog	t	2025-12-20 13:45:58.254541+00	\N
2	Endometriosis Test	Diagnostic test	endometriosis_test	t	2025-12-20 13:45:58.254541+00	\N
3	Gallery	Image gallery	gallery	t	2025-12-20 13:45:58.254541+00	\N
4	Testimonials	Patient reviews	testimonials	t	2025-12-20 13:45:58.254541+00	\N
5	FAQ	Frequently asked questions	faq	t	2025-12-20 13:45:58.254541+00	\N
6	Services	Services list	services	t	2025-12-20 13:45:58.254541+00	\N
7	Locations	Office locations	locations	t	2025-12-20 13:45:58.254541+00	\N
\.


--
-- Data for Name: patients; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.patients (id, name, email, phone, date_of_birth, medical_history, created_at, updated_at, tenant_id) FROM stdin;
\.


--
-- Data for Name: plans; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.plans (id, name, description, price, features, max_testimonials, max_gallery_images, max_faqs, custom_domain, analytics_dashboard, priority_support, is_active, created_at, updated_at) FROM stdin;
1	Plan Básico	Plan inicial	0.00	{}	10	20	15	f	f	f	t	2025-12-20 13:22:05.021024+00	\N
\.


--
-- Data for Name: preconsultation_questions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.preconsultation_questions (id, text, type, category, required, options, "order", is_active) FROM stdin;
\.


--
-- Data for Name: services; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.services (id, doctor_id, title, description, image_url, is_active, "order", blog_slug) FROM stdin;
1	4	Consulta Ginecológica	Evaluación integral de la salud femenina.	\N	t	0	\N
2	4	Control Prenatal	Acompañamiento médico durante todo el embarazo.	\N	t	1	\N
3	4	Ecosonografía	Ecosonogramas pélvicos y obstétricos de alta resolución.	\N	t	2	\N
4	4	Despistaje de Endometriosis	Diagnóstico especializado y tratamiento.	\N	t	3	entendiendo-la-endometriosis
\.


--
-- Data for Name: tenant_modules; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tenant_modules (tenant_id, module_id, is_enabled, created_at, updated_at) FROM stdin;
4	1	t	2025-12-20 13:45:58.254541+00	\N
4	2	t	2025-12-20 13:45:58.254541+00	\N
4	3	t	2025-12-20 13:45:58.254541+00	\N
4	4	t	2025-12-20 13:45:58.254541+00	\N
4	5	t	2025-12-20 13:45:58.254541+00	\N
4	6	t	2025-12-20 13:45:58.254541+00	\N
4	7	t	2025-12-20 13:45:58.254541+00	\N
\.


--
-- Data for Name: tenants; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tenants (id, email, password_hash, nombre_completo, telefono, especialidad, biografia, slug, logo_url, photo_url, theme_primary_color, plan_id, status, is_verified, stripe_customer_id, subscription_end_date, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: testimonials; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.testimonials (id, doctor_id, patient_name, patient_email, photo_url, content, rating, is_approved, is_featured, created_at, updated_at) FROM stdin;
1	4	Ana García	\N	\N	Excelente atención, la doctora es muy profesional y amable.	5	t	f	2025-12-20 13:32:09.517681+00	\N
2	4	María Rodríguez	\N	\N	Me sentí muy cómoda en la consulta, resolvió todas mis dudas.	5	t	f	2025-12-20 13:32:09.517681+00	\N
3	4	Carla Pérez	\N	\N	Gran especialista en endometriosis, totalmente recomendada.	5	t	f	2025-12-20 13:32:09.517681+00	\N
\.


--
-- Name: appointments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.appointments_id_seq', 1, false);


--
-- Name: blog_comments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.blog_comments_id_seq', 1, false);


--
-- Name: blog_posts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.blog_posts_id_seq', 8, true);


--
-- Name: consultations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.consultations_id_seq', 1, false);


--
-- Name: doctors_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.doctors_id_seq', 4, true);


--
-- Name: faqs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.faqs_id_seq', 3, true);


--
-- Name: gallery_images_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.gallery_images_id_seq', 5, true);


--
-- Name: locations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.locations_id_seq', 2, true);


--
-- Name: modules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.modules_id_seq', 7, true);


--
-- Name: patients_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.patients_id_seq', 1, false);


--
-- Name: plans_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.plans_id_seq', 1, true);


--
-- Name: services_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.services_id_seq', 4, true);


--
-- Name: tenants_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tenants_id_seq', 1, false);


--
-- Name: testimonials_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.testimonials_id_seq', 3, true);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: appointments appointments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_pkey PRIMARY KEY (id);


--
-- Name: blog_comments blog_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blog_comments
    ADD CONSTRAINT blog_comments_pkey PRIMARY KEY (id);


--
-- Name: blog_posts blog_posts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blog_posts
    ADD CONSTRAINT blog_posts_pkey PRIMARY KEY (id);


--
-- Name: consultations consultations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.consultations
    ADD CONSTRAINT consultations_pkey PRIMARY KEY (id);


--
-- Name: doctors doctors_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.doctors
    ADD CONSTRAINT doctors_pkey PRIMARY KEY (id);


--
-- Name: faqs faqs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.faqs
    ADD CONSTRAINT faqs_pkey PRIMARY KEY (id);


--
-- Name: gallery_images gallery_images_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gallery_images
    ADD CONSTRAINT gallery_images_pkey PRIMARY KEY (id);


--
-- Name: locations locations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.locations
    ADD CONSTRAINT locations_pkey PRIMARY KEY (id);


--
-- Name: modules modules_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.modules
    ADD CONSTRAINT modules_pkey PRIMARY KEY (id);


--
-- Name: patients patients_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.patients
    ADD CONSTRAINT patients_pkey PRIMARY KEY (id);


--
-- Name: plans plans_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plans
    ADD CONSTRAINT plans_pkey PRIMARY KEY (id);


--
-- Name: preconsultation_questions preconsultation_questions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.preconsultation_questions
    ADD CONSTRAINT preconsultation_questions_pkey PRIMARY KEY (id);


--
-- Name: services services_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT services_pkey PRIMARY KEY (id);


--
-- Name: tenant_modules tenant_modules_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tenant_modules
    ADD CONSTRAINT tenant_modules_pkey PRIMARY KEY (tenant_id, module_id);


--
-- Name: tenants tenants_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_pkey PRIMARY KEY (id);


--
-- Name: testimonials testimonials_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.testimonials
    ADD CONSTRAINT testimonials_pkey PRIMARY KEY (id);


--
-- Name: ix_appointments_doctor_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_appointments_doctor_id ON public.appointments USING btree (doctor_id);


--
-- Name: ix_appointments_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_appointments_id ON public.appointments USING btree (id);


--
-- Name: ix_blog_comments_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_blog_comments_id ON public.blog_comments USING btree (id);


--
-- Name: ix_blog_posts_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_blog_posts_id ON public.blog_posts USING btree (id);


--
-- Name: ix_blog_posts_is_in_menu; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_blog_posts_is_in_menu ON public.blog_posts USING btree (is_in_menu);


--
-- Name: ix_blog_posts_slug; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_blog_posts_slug ON public.blog_posts USING btree (slug);


--
-- Name: ix_blog_posts_title; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_blog_posts_title ON public.blog_posts USING btree (title);


--
-- Name: ix_consultations_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_consultations_id ON public.consultations USING btree (id);


--
-- Name: ix_doctors_email; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_doctors_email ON public.doctors USING btree (email);


--
-- Name: ix_doctors_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_doctors_id ON public.doctors USING btree (id);


--
-- Name: ix_doctors_slug_url; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_doctors_slug_url ON public.doctors USING btree (slug_url);


--
-- Name: ix_faqs_doctor_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_faqs_doctor_id ON public.faqs USING btree (doctor_id);


--
-- Name: ix_faqs_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_faqs_id ON public.faqs USING btree (id);


--
-- Name: ix_gallery_images_doctor_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_gallery_images_doctor_id ON public.gallery_images USING btree (doctor_id);


--
-- Name: ix_gallery_images_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_gallery_images_id ON public.gallery_images USING btree (id);


--
-- Name: ix_locations_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_locations_id ON public.locations USING btree (id);


--
-- Name: ix_modules_code; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_modules_code ON public.modules USING btree (code);


--
-- Name: ix_modules_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_modules_id ON public.modules USING btree (id);


--
-- Name: ix_patients_email; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_patients_email ON public.patients USING btree (email);


--
-- Name: ix_patients_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_patients_id ON public.patients USING btree (id);


--
-- Name: ix_patients_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_patients_tenant_id ON public.patients USING btree (tenant_id);


--
-- Name: ix_plans_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_plans_id ON public.plans USING btree (id);


--
-- Name: ix_preconsultation_questions_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_preconsultation_questions_id ON public.preconsultation_questions USING btree (id);


--
-- Name: ix_services_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_services_id ON public.services USING btree (id);


--
-- Name: ix_tenants_email; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_tenants_email ON public.tenants USING btree (email);


--
-- Name: ix_tenants_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_tenants_id ON public.tenants USING btree (id);


--
-- Name: ix_tenants_slug; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_tenants_slug ON public.tenants USING btree (slug);


--
-- Name: ix_testimonials_doctor_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_testimonials_doctor_id ON public.testimonials USING btree (doctor_id);


--
-- Name: ix_testimonials_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_testimonials_id ON public.testimonials USING btree (id);


--
-- Name: appointments appointments_doctor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_doctor_id_fkey FOREIGN KEY (doctor_id) REFERENCES public.doctors(id);


--
-- Name: blog_comments blog_comments_post_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blog_comments
    ADD CONSTRAINT blog_comments_post_id_fkey FOREIGN KEY (post_id) REFERENCES public.blog_posts(id);


--
-- Name: blog_posts blog_posts_doctor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blog_posts
    ADD CONSTRAINT blog_posts_doctor_id_fkey FOREIGN KEY (doctor_id) REFERENCES public.doctors(id);


--
-- Name: consultations consultations_doctor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.consultations
    ADD CONSTRAINT consultations_doctor_id_fkey FOREIGN KEY (doctor_id) REFERENCES public.doctors(id);


--
-- Name: consultations consultations_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.consultations
    ADD CONSTRAINT consultations_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id);


--
-- Name: doctors doctors_plan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.doctors
    ADD CONSTRAINT doctors_plan_id_fkey FOREIGN KEY (plan_id) REFERENCES public.plans(id);


--
-- Name: faqs faqs_doctor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.faqs
    ADD CONSTRAINT faqs_doctor_id_fkey FOREIGN KEY (doctor_id) REFERENCES public.doctors(id);


--
-- Name: tenant_modules fk_tenant_modules_doctors; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tenant_modules
    ADD CONSTRAINT fk_tenant_modules_doctors FOREIGN KEY (tenant_id) REFERENCES public.doctors(id);


--
-- Name: gallery_images gallery_images_doctor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gallery_images
    ADD CONSTRAINT gallery_images_doctor_id_fkey FOREIGN KEY (doctor_id) REFERENCES public.doctors(id);


--
-- Name: locations locations_doctor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.locations
    ADD CONSTRAINT locations_doctor_id_fkey FOREIGN KEY (doctor_id) REFERENCES public.doctors(id);


--
-- Name: services services_doctor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT services_doctor_id_fkey FOREIGN KEY (doctor_id) REFERENCES public.doctors(id);


--
-- Name: tenant_modules tenant_modules_module_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tenant_modules
    ADD CONSTRAINT tenant_modules_module_id_fkey FOREIGN KEY (module_id) REFERENCES public.modules(id);


--
-- Name: tenants tenants_plan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_plan_id_fkey FOREIGN KEY (plan_id) REFERENCES public.plans(id);


--
-- Name: testimonials testimonials_doctor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.testimonials
    ADD CONSTRAINT testimonials_doctor_id_fkey FOREIGN KEY (doctor_id) REFERENCES public.doctors(id);


--
-- PostgreSQL database dump complete
--

\unrestrict NwizehYeairjyhWg7mvIH9gcLvNhwedECpunq5kF1YbaD17HWDwD1kiw31Nb60y

